function res_hist = computeJointHistogram(A,B, binWidth)
   binMax = floor(256/binWidth)+1;
   res_hist = zeros(binMax, binMax);
   for i = 1:numel(A)
       bin_index1 = floor(A(i)/binWidth)+1;
       bin_index2 = floor(B(i)/binWidth)+1;
       res_hist(bin_index1,bin_index2) = res_hist(bin_index1,bin_index2) + 1;
   end
end