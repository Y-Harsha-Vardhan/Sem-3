clear; clc; close all;

% Setting up the given data into variables
n = 1000;
p_data = [1e-4, 5e-4, 0.001, 0.005, 0.01, 0.02, 0.05, 0.08, 0.1, 0.2];

e_t1 = zeros(size(p_data));
e_t2 = zeros(size(p_data));

for i = 1:length(p_data)
    p = p_data(i);

    % Calculating the estimated number of tests using method-1
    s_opt = round(1/sqrt(p));
    s = max(1, s_opt);
    e_t1(i) = (n/s) + n*(1 - (1-p)^s);

    % Calculating the estimated number of tests using method-2
    pi_opt = 1/(n*p);
    if pi_opt > 1
        pi_opt = 1;
    end

    T1_opt = 1;
    e_t2(i) = 1 + n*p*(1 - exp(-pi_opt * T1_opt)) ...
                + n*(1-p)*(1 - exp(-n*p*T1_opt*pi_opt^2));
    
end


% Plotting the obtained values in a graph
figure;

semilogx(p_data, e_t1, '-o', 'LineWidth', 2, 'DisplayName', 'Method-1');
hold on;

semilogx(p_data, e_t2, '-s', 'LineWidth', 2, 'DisplayName', 'Method-2 (using optimal pi,T1)');

semilogx(p_data, ones(size(p_data)) * n, '--k', 'LineWidth', 1.5, 'DisplayName', 'Individual Testing (n=1000)');

grid on;
title('Comparison of Group Testing Methods (n=1000)');
xlabel('Prevalence Rate (p)');
ylabel('Expected Number of Tests');
legend('show', 'Location', 'northwest');
ylim([0, n + 100]);
hold off;