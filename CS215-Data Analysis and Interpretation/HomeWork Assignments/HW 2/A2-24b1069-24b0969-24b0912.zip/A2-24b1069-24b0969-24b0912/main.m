%% Main Script: Correlation, QMI, and MI Analysis for Image Alignment
% This script analyzes image alignment using correlation coefficient (ρ),
% Quadratic Mutual Information (QMI), and Mutual Information (MI) for 
% different scenarios: identical images, shifted images, and noisy images.

clear; close all; clc;

% Load two images, Img1 and Img2. Img1 is used as the reference.
Img1 = double(imread('T1.jpg'));
Img2 = double(imread('T2.jpg'));

% Create a negatively correlated image (inverted) and a non-linearly
% related image (squared) to test different relationships.
I2_neg = 255 - Img1;
I2_sq1 = 255 * (Img1.^2) / max(Img1(:).^2) + 1; 

% Define the range of horizontal shifts (t_x) to test, from -10 to +10 pixels.
tx_range = -10:10;

% Calculate correlation, QMI, and MI for three different image pairs:
% 1. Img1 vs. Img2 (typically a shifted version of Img1)
[cor0,QMI0,MI0] = measureCurves(Img1, Img2); 

% 2. Img1 vs. I2_neg (negatively correlated/inverted)
[cor1,QMI1,MI1] = measureCurves(Img1, I2_neg); 

% 3. Img1 vs. I2_sq1 (non-linearly related)
[cor2,QMI2,MI2] = measureCurves(Img1, I2_sq1);  
% Plotting all the Correlation Coefficient vs. Shift graphs for the 3 cases


% This function calculates the correlation coefficient, QMI, and MI for two images
% over a range of horizontal shifts.
function [cor,QMI,MI] = measureCurves(Img1, Img2)
tx_range = -10:10;
[m,n]= size(Img1);
cor = zeros(size(tx_range)); % Initialize array to store correlation values
QMI = zeros(size(tx_range)); % Initialize array to store QMI values
MI  = zeros(size(tx_range)); % Initialize array to store MI values
    for k = 1:numel(tx_range)
         tx  = tx_range(k); % Get the current shift value
        shiftImg2 = zeros(m,n,'like',Img1);
        % Shift Img2 horizontally by tx pixels
        if tx<0
            t = -tx;
            shiftImg2(:,t+1:n) = Img2(:,1:n-t);
        elseif tx>0
            shiftImg2(:,1:n-tx) = Img2(:,tx+1:n);
        else
            shiftImg2 = Img2; 
        end
    
        % Find pixels that are valid in both images after the shift
        pixelVal = (Img1>0) & (shiftImg2>0);
        val_img1 = Img1(pixelVal);
        val_img2 = shiftImg2(pixelVal);  
    
        % Calculating the correlation coefficient
        cor(k) = corr2(val_img1, val_img2);
    
        % Computing the joint histogram to find the relationship between pixel pairs
        H = computeJointHistogram(val_img1,val_img2,10);
        joint_hist = H / sum(H(:)); % Normalize the histogram to get a joint probability distribution
    
        % Calculating marginal probabilities from the joint histogram
        marg_I1 = sum(joint_hist, 2); 
        marg_I2 = sum(joint_hist, 1); 
    
        % Calculating Quadratic Mutual Information (QMI)
        QMI(k) = sum(sum((joint_hist - (marg_I1*marg_I2)).^2));
    
        p1 = sum(joint_hist, 2);              
        p2 = sum(joint_hist, 1);  
        prod = p1 * p2; % The product of the marginal probabilities
        
        eps_ = 1e-12; % A small value to prevent log(0)
        % Calculating Mutual Information (MI)
        MI(k) = sum( joint_hist(:) .* log( (joint_hist(:)+eps_) ./ (prod(:)+eps_) ) );
    end
end

figure;
plot(tx_range, cor0, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('\cor_coeff'); title('Correlation Coefficient vs Shift t_x');
figure;
plot(tx_range, cor1, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('\cor_coeff'); title('Correlation Coefficient vs Shift t_x');
figure;
plot(tx_range, cor2, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('\cor_coeff'); title('Correlation Coefficient vs Shift t_x');
% Plotting all the QMI vs. Shift graphs for the 3 cases
figure;
plot(tx_range, QMI0, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('QMI'); title('QMI vs Shift t_x');
figure;
plot(tx_range, QMI1, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('QMI'); title('QMI vs Shift t_x');
figure;
plot(tx_range, QMI2, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('QMI'); title('QMI vs Shift t_x');
% Plotting all the MI vs. Shift graphs for the 3 cases
figure;
plot(tx_range, MI0, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('MI (nats)'); title('Mutual Information vs Shift t_x');
figure;
plot(tx_range, MI1, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('MI (nats)'); title('Mutual Information vs Shift t_x');
figure;
plot(tx_range, MI2, 'o-','LineWidth',1.2,'MarkerSize',5); grid on;
xlabel('t_x (pixels)'); ylabel('MI (nats)'); title('Mutual Information vs Shift t_x');
%imagesc(joint_hist);
