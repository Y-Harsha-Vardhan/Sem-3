nasm -f elf64 add-nums.asm -o add-nums.o
ld add-nums.o -o add-nums