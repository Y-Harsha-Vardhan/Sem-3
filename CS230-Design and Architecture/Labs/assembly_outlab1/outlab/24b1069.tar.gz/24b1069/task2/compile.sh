nasm -f elf64 run-gdb.asm -o run-gdb.o
ld run-gdb.o -o run-gdb