nasm -f elf64 loops.asm -o loops.o
ld loops.o -o loops